﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript : MonoBehaviour {

    //public waypoint list as an array of positions
    public Vector3[] waypoints;
	
}
