﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript : MonoBehaviour {

    //The first waypoint of the chain
    public Waypoint firstWaypoint;
	
}
